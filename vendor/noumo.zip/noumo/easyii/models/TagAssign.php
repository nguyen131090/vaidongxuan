<?php
namespace yii\easyii\models;

class TagAssign extends \yii\easyii\components\ActiveRecord
{
    public static function tableName()
    {
        return 'easyii_tags_assign';
    }
}