<?php
namespace yii\easyii\models;

use Yii;
use yii\easyii\behaviors\SortableModel;

class ContentMobile extends \yii\easyii\components\ActiveRecord
{

    public static function tableName()
    {
        return 'easyii_contents_mobile';
    }

    public function rules()
    {
        return [
            [['class', 'entry_id', 'description'], 'required'],
            ['entry_id', 'integer'],
			['type', 'safe'],
        ];
    }

    public function behaviors()
    {
        return [
            SortableModel::className()
        ];
    }

   
}