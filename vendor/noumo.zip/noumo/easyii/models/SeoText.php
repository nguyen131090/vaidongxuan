<?php
namespace yii\easyii\models;

use Yii;
use yii\easyii\validators\EscapeValidator;

class SeoText extends \yii\easyii\components\ActiveRecord
{
    public static function tableName()
    {
        return 'easyii_seotext';
    }

    public function rules()
    {
        return [
            [['h1', 'title', 'keywords', 'description', 'breadcrumb'], 'trim'],
			[['social'], 'safe'],
            [['h1', 'title', 'keywords', 'description', 'breadcrumb'], 'string', 'max' => 320],
            [['seo_content'], 'safe']
            // [['h1', 'title', 'keywords', 'description'], EscapeValidator::className()],
        ];
    }

    public function attributeLabels()
    {
        return [
            'h1' => 'Seo H1',
            'title' => 'Seo Title',
            'keywords' => 'Seo Keywords',
            'description' => 'Seo Description',
            'breadcrumb' => 'Seo Breadcrumb',
        ];
    }

    public function isEmpty()
    {
        return (!$this->h1 && !$this->title && !$this->keywords && !$this->description);
    }
}