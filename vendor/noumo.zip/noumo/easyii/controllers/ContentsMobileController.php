<?php
namespace yii\easyii\controllers;

use Yii;
use yii\helpers\Url;
use yii\web\UploadedFile;
use yii\web\Response;

use yii\easyii\helpers\Image;
use yii\easyii\components\Controller;
use yii\easyii\models\ContentMobile;
use yii\easyii\behaviors\SortableController;

class ContentsMobileController extends Controller
{
    public function behaviors()
    {
        return [
            [
                'class' => 'yii\filters\ContentNegotiator',
                'formats' => [
                    'application/json' => Response::FORMAT_JSON
                ],
            ],
            [
                'class' => SortableController::className(),
                'model' => ContentMobile::className(),
            ]
        ];
    }

    public function actionAbc($class, $item_id){
        echo "a";exit;
    }

    public function actionAdd($class, $item_id)
    {
        $success = null;
        $model = new ContentMobile;
        $model->class = $class;
        $model->entry_id = $item_id;
        $model->description = Yii::$app->request->post('description');
        if($model->save()){
                    $success = [
                        'message' => 'Contents Mobile saved',
                        'content' => [
                            'id' => $model->primaryKey,
                            'description' => $model->description,
                            'type' => $model->type
                        ]
                    ];
         }
        return $this->formatResponse($success);
    }

    public function actionDescription($id){
        if(($model = ContentMobile::findOne($id)))
        {
            if(Yii::$app->request->post('description'))
            {
                $model->description = Yii::$app->request->post('description');
                $model->type = Yii::$app->request->post('type');
                if(!$model->update()) {
                    $this->error = Yii::t('easyii', 'Update error. {0}', $model->formatErrors());
                }
            }
            else{
                $this->error = Yii::t('easyii', 'Bad response');
            }
        }
        else{
            $this->error = Yii::t('easyii', 'Not found');
        }

        return $this->formatResponse('Content saved');
    }

    

    public function actionDelete($id)
    {
        if(($model = ContentMobile::findOne($id))){
            $model->delete();
        } else {
            $this->error = Yii::t('easyii', 'Not found');
        }
        return $this->formatResponse('Content deleted');
    }
}