#Changelog

###0.8.0
* Articles module added
* FAQ module added
* SEO h1, title, description, keywords fields added
* Ability to create modules outside vendor path
* New root menu item - System
* Migrations integrated
* WebConsole added
* Slug attached to news
* Photos module reworked
* Colorbox changed to Fancybox
* Fancybox and jquery.switcher moved to bower-assets
* Many core improvements

###0.7.4
* SluggableBehavior integrated

###0.7.3
* Photo multi upload added

###0.7.2
* GD support added (image scale quality improved)

###0.7.1
* Minor fixes