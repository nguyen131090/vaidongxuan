<?php
return [
    'Gallery' => 'گالری',
    'Albums' => 'آلبوم ها',
    'Create album' => 'ایجاد آلبوم',
    'Edit album' => 'ویرایش آلبوم',
    'Album created' => 'آلبوم ایجاد شد',
    'Album updated' => 'آلبوم ویرایش شد',
    'Album deleted' => 'آلبوم حذف شد',
];