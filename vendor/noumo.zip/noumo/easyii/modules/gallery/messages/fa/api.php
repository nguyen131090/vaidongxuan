<?php
return [
    'Create album' => 'Создать альбом',
];