<?php
return [
    'Gallery' => 'Фотогалерея',
    'Albums' => 'Альбомы',
    'Create album' => 'Создать альбом',
    'Edit album' => 'Редактировать альбом',
    'Album created' => 'Альбом успешно создан',
    'Album updated' => 'Альбом обновлен',
    'Album deleted' => 'Альбом удален',
];