<?php
return [
    'Carousel' => 'اسلایدشو',
    'Create carousel' => 'ایجاد اسلایدشو',
    'Edit carousel' => 'ویرایش اسلایدشو',
    'Carousel created' => 'اسلایدشو ایجاد شد',
    'Carousel updated' => 'اسلایدشو ویرایش شد',
    'Carousel item deleted' => 'آیتم اسلاید حذف شد',
    'Link'=>'لینک',
];