<?php
return [
    'Create carousel' => 'ایجاد اسلاید',
];