<?php
return [
    'Carousel' => 'Карусель',
    'Create carousel' => 'Создать карусель',
    'Edit carousel' => 'Редактировать карусель',
    'Carousel created' => 'Карусель успешно создана',
    'Carousel updated' => 'Карусель обновлена',
    'Carousel item deleted' => 'Элемент карусели удален'
];