<?php
return [
    'Create carousel' => 'Создать карусель',
];