<?php
namespace yii\easyii\modules\carousel\api;

class CarouselObject extends \yii\easyii\components\ApiObject
{
    public $image;
    public $link;
    public $title;
    public $text;
}