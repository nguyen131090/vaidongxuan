<?php
$this->title = Yii::t('easyii/carousel', 'Create carousel');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>