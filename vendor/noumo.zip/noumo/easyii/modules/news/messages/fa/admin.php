<?php
return [
    'News' => 'اخبار',
    'Create news' => 'ایجاد خبر',
    'Edit news' => 'ویرایش خبر',
    'News created' => 'خبر ایجاد شد',
    'News updated' => 'خبر ویرایش شد',
    'News deleted' => 'خبر حذف شد',
    'News image cleared' => 'عکس های خبر پاک شد',
    'Short' => 'کوتاه',
    'Clear image' => 'پاک کردن عکس',
];