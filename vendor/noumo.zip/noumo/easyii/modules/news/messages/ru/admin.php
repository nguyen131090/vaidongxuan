<?php
return [
    'News' => 'Новости',
    'Create news' => 'Создать новость',
    'Edit news' => 'Редактировать новость',
    'News created' => 'Новость успешно создана',
    'News updated' => 'Новость обновлена',
    'News deleted' => 'Новость удалена',
    'Short' => 'Коротко',
];