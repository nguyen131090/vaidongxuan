<?php
return [
    'Create text' => 'ایحاد متن',
];