<?php
return [
    'Texts' => 'متن های وب سایت',
    'Create text' => 'ایجاد متن',
    'Edit text' => 'ویرایش متن',
    'Text created' => 'متن ایجاد شد',
    'Text updated' => 'متن ویرایش شد',
    'Text deleted' => 'متن حذف شد'
];