<?php
return [
    'Create text' => 'Создать текст',
];