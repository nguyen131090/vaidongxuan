<?php
return [
    'Texts' => 'Текстовые блоки',
    'Create text' => 'Создать текст',
    'Edit text' => 'Редактировать текст',
    'Text created' => 'Текст успешно создан',
    'Text updated' => 'Текст обновлен',
    'Text deleted' => 'Текст удален'
];