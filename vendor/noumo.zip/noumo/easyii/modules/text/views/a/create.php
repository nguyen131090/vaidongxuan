<?php
$this->title = Yii::t('easyii/text', 'Create text');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>