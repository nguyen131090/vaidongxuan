<?php
return [
    'Catalog' => 'Каталог',
    'Category fields' => 'Поля категории',
    'Manage fields' => 'Редактировать поля',

    'Add field' => 'Добавить поле',
    'Save fields' => 'Сохранить поля',
    'Type options with `comma` as delimiter' => 'Элементы списка через запятую',
    'Fields' => 'Поля',

    'Item created' => 'Новая запись успешно создана',
    'Item updated' => 'Запись обновлена',
    'Item deleted' => 'Запись удалена',

    'Title' => 'Название',
    'Type' => 'Тип поля',
    'Options' => 'Опции',
    'Available' => 'Доступно',
    'Price' => 'Цена',
    'Discount' => 'Скидка',
    'Select' => 'Выбрать',
];