<?php
return [
    'Create category' => 'ایجاد دسته',
];