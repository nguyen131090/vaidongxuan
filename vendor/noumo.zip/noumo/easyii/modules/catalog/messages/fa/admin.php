<?php
return [
    'Catalog' => 'محصولات',
    'Category fields' => 'فیلدهای محصولات',
    'Manage fields' => 'مدیریت فیلدها',

    'Add field' => 'افزودن فیلد',
    'Save fields' => 'ذخیره کردن فیلد ها',
    'Type options with `comma` as delimiter' => 'با کاما وارد کنید',
    'Fields' => 'فیلد ها',

    'Item created' => 'آیتم ایجاد شد',
    'Item updated' => 'آیتم ویرایش شد',
    'Item deleted' => 'آیتم حذف شد',

    'Title' => 'عنوان',
    'Type' => 'نوع',
    'Options' => 'انتخاب ها',
    'Available' => 'در دسترس',
    'Price' => 'قیمت',
    'Discount' => 'تخفیف',
    'Select' => 'انتخاب',
];