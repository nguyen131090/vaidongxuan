<?php
return [
    'Guestbook' => 'نظرات',
    'Guestbook updated' => 'نظر ویرایش شد',
    'View post' => 'مشاهده پست',
    'Entry deleted' => 'مورد حذف شد',
    'Answer' => 'پاسخ',
    'No answer' => 'بدون پاسخ',
    'Mark all as viewed' => 'همه خوانده شده است',
    'Answer successfully saved' => 'پاسخ با موفقیت ذخیره شد',
    'Mark as new' => 'این مورد جدید است',
    'Notify user about answer' => 'کاربر را از پاسخ آگاه کن'
];