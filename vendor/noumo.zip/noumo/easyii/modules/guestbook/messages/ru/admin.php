<?php
return [
    'Guestbook' => 'Гостевая книга',
    'Guestbook updated' => 'Гостевая книга обновлена',
    'View post' => 'Просмотр записи',
    'Entry deleted' => 'Запись удалена',
    'Answer' => 'Ответ',
    'No answer' => 'Без ответа',
    'Mark all as viewed' => 'Отметить все как прочитанные',
    'Answer successfully saved' => 'Ответ успешно сохранен',
    'Mark as new' => 'Отметить как новое',
    'Notify user about answer' => 'Послать уведомление пользователю об ответе'
];