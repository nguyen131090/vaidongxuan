<?php
return [
    'Subscribe' => 'عضویت',
];