<?php
return [
    'Subscribe' => 'عضویت خبرنامه',
    'Subscribers' => 'اعضای خبرنامه',
    'Create subscribe' => 'ارسال خبرنامه',
    'History' => 'تاریخچه',
    'View subscribe history' => 'مشاهده تاریخچه ثبت نام',
    'Subscriber deleted' => 'عضویت حذف شد',
    'Subscribe successfully created and sent' => 'عضویت ایجاد شده و ارسال شد',
    'Subject' => 'موضوع',
    'Body' => 'متن',
    'Sent' => 'ارسال شد',
    'Unsubscribe' => 'لغو عضویت'
];