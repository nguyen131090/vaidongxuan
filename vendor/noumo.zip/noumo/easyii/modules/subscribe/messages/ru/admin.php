<?php
return [
    'Subscribe' => 'E-mail рассылка',
    'Subscribers' => 'Подписчики',
    'Create subscribe' => 'Создать рассылку',
    'History' => 'История',
    'View subscribe history' => 'Просмотр истории рассылки',
    'Subscriber deleted' => 'Подписчик удален',
    'Subscribe successfully created and sent' => 'Рассылка успешно создана и отправлена',
    'Subject' => 'Тема',
    'Body' => 'Сообщение',
    'Sent' => 'Отправлено',
    'Unsubscribe' => 'Отписаться от рассылки'
];