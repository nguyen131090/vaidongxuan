<?php
return [
    'Subscribe' => 'Подписаться',
];