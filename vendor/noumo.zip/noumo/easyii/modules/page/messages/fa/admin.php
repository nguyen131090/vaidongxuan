<?php
return [
    'Pages' => 'صفحات',
    'Create page' => 'ایجاد صفحه',
    'Edit page' => 'ویرایش صفحه',
    'Page created' => 'صفحه ایجاد شد',
    'Page updated' => 'صفحه ویرایش شد',
    'Page deleted' => 'صفحه حذف شد'
];