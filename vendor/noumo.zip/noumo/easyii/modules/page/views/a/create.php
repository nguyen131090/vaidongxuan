<?php
$this->title = Yii::t('easyii/page', 'Create page');
?>
<?= $this->render('_menu', ['model' => $model]) ?>
<?= $this->render('_form', ['model' => $model]) ?>