<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\easyii\widgets\Redactor;
use yii\easyii\widgets\SeoForm;
use wadeshuler\ckeditor\widgets\CKEditor;
?>
<?php $form = ActiveForm::begin([
    'enableAjaxValidation' => true,
    'options' => ['class' => 'model-form']
]); ?>
<?= $form->field($model, 'title') ?>
<?= $form->field($model, 'summary')->textArea() ?>
<?= $form->field($model, 'text')->widget(CKEditor::className());?>

<?php if(IS_ROOT || IS_SEO) : ?>
    <?= $form->field($model, 'slug') ?>
   
<?php endif; ?>
 <?= SeoForm::widget(['model' => $model]) ?>
<?= Html::submitButton(Yii::t('easyii','Save'), ['class' => 'btn btn-primary']) ?>
<?php ActiveForm::end(); ?>