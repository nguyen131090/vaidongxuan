<?php
namespace yii\easyii\modules\page\api;

use Yii;
use yii\easyii\components\API;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\easyii\models\Photo;
use yii\easyii\models\ContentMobile;

class PageObject extends \yii\easyii\components\ApiObject
{
    public $slug;
    private $_photos;
    private $_photosMobile;
    private $_contentsMobile;
    private $_photosArray;

    public function getTitle(){
        if($this->model->isNewRecord){
            return $this->createLink;
        } else {
            return LIVE_EDIT ? API::liveEdit($this->model->title, $this->editLink) : $this->model->title;
        }
    }

    public function getText(){
        if($this->model->isNewRecord){
            return $this->createLink;
        } else {
            return LIVE_EDIT ? API::liveEdit($this->model->text, $this->editLink, 'div') : $this->model->text;
        }
    }

    public function getEditLink(){
        return Url::to(['/admin/page/a/edit/', 'id' => $this->id]);
    }

    public function getCreateLink(){
        return Html::a(Yii::t('easyii/page/api', 'Create page'), ['/admin/page/a/create', 'slug' => $this->slug], ['target' => '_blank']);
    }
     public function getPhotos()
    {
        if(!$this->_photos){
            $this->_photos = [];

            foreach(Photo::find()->where(['class' => 'yii\easyii\modules\page\models\Page', 'item_id' => $this->id])->sort()->all() as $model){
                $this->_photos[] = new PhotoObject($model);
            }
        }
        return $this->_photos;
    }
    
    public function parents(){
        return false;
    }
    public function getPhotosArray()
    {
        if(!$this->_photosArray){
            foreach(Photo::find()->where(['class' => 'yii\easyii\modules\page\models\Page', 'item_id' => $this->id])->orderBy(['order_num' => SORT_ASC])->all() as $model){
                $this->_photosArray[$model->type][] = new PhotoObject($model);
            }
        }

        return $this->_photosArray;
    }

    public function getPhotosMobile()
    {

        $this->_photosMobile = [];
        if(!$this->_photosMobile){
            foreach(Photo::find()->where(['class' => Page::className(), 'item_id' => $this->id])->andWhere(['like', 'type', 'mobile'])->orderBy(['order_num' => SORT_ASC])->all() as $model){
                $this->_photosMobile[] = new PhotoObject($model);
            }
        }
        return $this->_photosMobile;
    }

    public function getContentsMobile()
    {
        $this->_contentsMobile = [];
        if(!$this->_contentsMobile){
            foreach(ContentMobile::find()->where(['class' => Page::className(), 'entry_id' => $this->id])->orderBy(['order_num' => SORT_ASC])->all() as $model){
                $this->_contentsMobile[] = new ContentMobileObject($model);
            }
        }
        return $this->_contentsMobile;
    }

}