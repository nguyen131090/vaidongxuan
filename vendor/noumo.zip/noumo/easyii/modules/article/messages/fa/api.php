<?php
return [
    'Create category' => 'Создать категорию',
];