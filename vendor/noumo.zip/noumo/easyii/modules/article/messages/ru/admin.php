<?php
return [
    'Articles' => 'Статьи',
    'Article' => 'Статья',

    'Short' => 'Короткий текст',

    'Create article' => 'Создать статью',
    'Edit article' => 'Редактировать статью',
    'Article created' => 'Новая статья успешно создана',
    'Article updated' => 'Статья обновлена',
    'Article deleted' => 'Статья удалена',
];