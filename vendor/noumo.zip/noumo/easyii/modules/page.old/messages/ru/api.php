<?php
return [
    'Create page' => 'Создать страницу',
];