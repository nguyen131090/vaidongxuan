<?php
return [
    'Pages' => 'Страницы',
    'Create page' => 'Создать страницу',
    'Edit page' => 'Редактировать страницу',
    'Page created' => 'Страница успешно создана',
    'Page updated' => 'Страница обновлена',
    'Page deleted' => 'Страница удалена'
];