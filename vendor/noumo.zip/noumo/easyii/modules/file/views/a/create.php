<?php
$this->title = Yii::t('easyii/file', 'Create file');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>