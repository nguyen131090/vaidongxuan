<?php
$this->title = Yii::t('easyii/file', 'Edit file');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>