<?php
return [
    'Files' => 'Файлы',
    'Create file' => 'Создать файл',
    'Edit file' => 'Редактировать файл',
    'File created' => 'Файл успешно создан',
    'File updated' => 'Файл обновлен',
    'File error. {0}' => 'Ошибка файла. {0}',
    'File deleted' => 'Файл удален',

    'Size' => 'Размер',
    'Downloads' => 'Скачиваний',
    'Download file' => 'Скачать файл',
];