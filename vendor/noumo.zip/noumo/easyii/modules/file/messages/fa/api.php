<?php
return [
    'Create file' => 'Создать файл',
    'File not found' => 'Файл не найден'
];