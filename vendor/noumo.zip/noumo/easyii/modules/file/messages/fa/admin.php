<?php
return [
    'Files' => 'فایل ها',
    'Create file' => 'ایجاد فایل',
    'Edit file' => 'ویرایش فایل',
    'File created' => 'فایل ایجا شد',
    'File updated' => 'فایل ویرایش شد',
    'File error. {0}' => 'فایل خطا',
    'File deleted' => 'فایل حذف شد',

    'Size' => 'سایز',
    'Downloads' => 'دانلود ها',
    'Download file' => 'دانلود فایل',
];