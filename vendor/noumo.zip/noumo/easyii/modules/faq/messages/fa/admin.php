<?php
return [
    'FAQ' => 'سوالات متداول',
    'Question' => 'سوال',
    'Answer' => 'پاسخ',
    'Create entry' => 'ایجاد مورد',
    'Edit entry' => 'ویرایش یک مورد',
    'Entry created' => 'مورد ایجاد شد',
    'Entry updated' => 'مورد ویرایش شد',
    'Entry deleted' => 'مورد حذف شد'
];