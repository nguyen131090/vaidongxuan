<?php
return [
    'FAQ' => 'Вопросы и ответы',
    'Question' => 'Вопрос',
    'Answer' => 'Ответ',
    'Create entry' => 'Создать запись',
    'Edit entry' => 'Редактировать запись',
    'Entry created' => 'Запись успешно создана',
    'Entry updated' => 'Запись обновлена',
    'Entry deleted' => 'Запись удалена'
];