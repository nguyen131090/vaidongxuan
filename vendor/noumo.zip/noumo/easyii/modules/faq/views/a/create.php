<?php
$this->title = Yii::t('easyii/faq', 'Create entry');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>