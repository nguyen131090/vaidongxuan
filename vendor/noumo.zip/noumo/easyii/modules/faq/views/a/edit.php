<?php
$this->title = Yii::t('easyii/faq', 'Edit entry');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>