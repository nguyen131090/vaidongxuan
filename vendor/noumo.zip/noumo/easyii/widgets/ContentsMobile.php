<?php
namespace yii\easyii\widgets;

use Yii;
use yii\base\Widget;
use yii\base\InvalidConfigException;
use yii\easyii\models\ContentMobile;

class ContentsMobile extends Widget
{
    public $model;

    public function init()
    {
        parent::init();

        if (empty($this->model)) {
            throw new InvalidConfigException('Required `model` param isn\'t set.');
        }
    }

    public function run()
    {
        $contents = ContentMobile::find()->where(['class' => get_class($this->model), 'entry_id' => $this->model->primaryKey])->sort()->all();
        echo $this->render('contents_mobile', [
            'contents' => $contents
        ]);
    }

}