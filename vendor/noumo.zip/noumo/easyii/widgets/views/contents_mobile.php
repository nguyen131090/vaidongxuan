<?php
use yii\easyii\helpers\Image;
use yii\easyii\models\content;
use yii\easyii\widgets\Fancybox;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use wadeshuler\ckeditor\widgets\CKEditor;
use yii\easyii\assets\ContentsMobileAsset;
ContentsMobileAsset::register($this);
Fancybox::widget(['selector' => '.plugin-box']);

$class = get_class($this->context->model);
$item_id = $this->context->model->primaryKey;

$linkParams = [
    'class' => $class,
    'item_id' => $item_id,
];
$contentTemplate = '<tr data-id="{{content_id}}">'.(IS_ROOT ? '<td>{{content_id}}</td>' : '').'\
    <td><textarea id="ckeditor-{{content_id}}" class="form-control content-description ckeditor">{{content_description}}</textarea>\
        <a  data-id="{{content_id}}"  href="' . Url::to(['/admin/contents-mobile/description?id={{content_id}}']) . '" class="btn btn-sm btn-primary save-content-description">'. Yii::t('easyii', 'Save') .'</a>\
    </td>\
    <td>\
        <select class="selectpicker content-type">\
          <option value="" >Select...</option>\
        </select>\
    </td>\
    <td class="control vtop">\
        <div class="btn-group btn-group-sm" role="group">\
            <a href="' . Url::to(['/admin/contents-mobile/delete?id={{content_id}}']) . '" class="btn btn-default color-red delete-content" title="'. Yii::t('easyii', 'Delete item') .'"><span class="glyphicon glyphicon-remove"></span></a>\
        </div>\
    </td>\
</tr>';
$this->registerJs("
var contentTemplate = '{$contentTemplate}';
$(function(){
    var elements = CKEDITOR.document.find( '.ckeditor' ),
    i = 0,
    element;
    while ( ( element = elements.getItem( i++ ) ) ) {
        CKEDITOR.replace( element );
    }
});
", \yii\web\View::POS_HEAD);
$contentTemplate = str_replace('>\\', '>', $contentTemplate);
?>
<button id="content-add" class="btn btn-success text-uppercase"><span class="glyphicon glyphicon-arrow-up"></span> <?= Yii::t('easyii', 'Add New')?></button>
<small id="uploading-text" class="smooth"><?= Yii::t('easyii', 'Adding. Please wait')?><span></span></small>

<table id="content-table" class="table table-hover" style="display: <?= count($contents) ? 'table' : 'none' ?>;">
    <thead>
    <tr>
        <?php if(IS_ROOT) : ?>
        <th width="50">#</th>
        <?php endif; ?>
         <th><?= Yii::t('easyii', 'Description') ?></th>
         <th width="100">Type</th>
        <th width="50"></th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($contents as $content) : ?>
        <?= str_replace(
            ['{{content_id}}', '{{content_description}}', '{{content_type}}','{{'.$content->type.'}}'],
            [$content->primaryKey, $content->description, $content->type, 'selected'],
            $contentTemplate)
        ?>
    <?php endforeach; ?>
    </tbody>
</table>
<p class="empty" style="display: <?= count($contents) ? 'none' : 'block' ?>;"><?= Yii::t('easyii', 'No content yet') ?>.</p>

<?= Html::beginForm(Url::to(['/admin/contents-mobile/add'] + $linkParams), 'post', ['id' => 'form-add', 'class' => 'hidden']) ?>
<? $model = new \yii\base\DynamicModel(['KOMENTAR']); 
$model->addRule(['KOMENTAR'], 'string', ['max' => 128]);
?>
<?= Html::textarea('description', '', [
    'id' => 'content-description',
    'class' => 'hidden ckeditor',
    'multiple' => 'multiple',
]);
?>
<?= Html::submitButton('Save', ['id' => 'content-save']);?>
<?php Html::endForm() ?>