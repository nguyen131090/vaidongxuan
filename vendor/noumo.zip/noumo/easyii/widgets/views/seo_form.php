<?php
use yii\bootstrap\BootstrapPluginAsset;
use yii\helpers\Html;
use kartik\file\FileInput;
use yii\helpers\Url;

BootstrapPluginAsset::register($this);

$labelOptions = ['class' => 'control-label'];
$inputOptions = ['class' => 'form-control'];
?>
    <!--GET DATA SOCIAL-->
<?php $social = json_decode($model->social); ?>
    <p>
        <a class="dashed-link collapsed" data-toggle="collapse" href="#seo-form" aria-expanded="false" aria-controls="seo-form"><?= Yii::t('easyii', 'Seo texts')?></a>
    </p>

<?= Html::activeTextarea($model, 'social', ['class' => 'hidden']); ?>
    <div class="collapse" id="seo-form">
        <div class="form-group">
            <?= Html::activeLabel($model, 'h1', $labelOptions) ?>
            <?= Html::activeTextInput($model, 'h1', $inputOptions) ?>
        </div>
        <div class="form-group">
            <?= Html::activeLabel($model, 'title', $labelOptions) ?>
            <?= Html::activeTextInput($model, 'title', $inputOptions) ?>
            <span id="count-title">0</span> chacracters
        </div>
        <div class="form-group">
        <?= Html::activeLabel($model, 'seo_content', $labelOptions) ?>
        <?= Html::activeTextarea($model, 'seo_content', ['class' => 'form-control ckeditor']) ?>
        </div>
        <div class="form-group">
            <?= Html::activeLabel($model, 'description', $labelOptions) ?>
            <?= Html::activeTextarea($model, 'description', $inputOptions) ?>
            <span id="count-description">0</span> chacracters
        </div>
        <div class="form-group">
            <?= Html::activeLabel($model, 'breadcrumb', $labelOptions) ?>
            <?= Html::activeTextarea($model, 'breadcrumb', $inputOptions) ?>
        </div>
    </div>

    <p>
        <a class="dashed-link collapsed" data-toggle="collapse" href="#seo-socials" aria-expanded="false" aria-controls="seo-socials"><?= Yii::t('easyii', 'Seo socials')?></a>
    </p>
    <div class="collapse" id="seo-socials">
        <div class="form-group">
            <label class="control-label" for="fb-title">Facebook Title</label>
            <?= Html::textarea('fb-title', (isset($social->title)) ? $social->title : '', ['class' => 'form-control']) ?>
        </div>
        <div class="form-group">
            <label class="control-label" for="fb-description">Facebook Description</label>
            <?= Html::textarea('fb-description', (isset($social->description)) ? $social->description : '', ['class' => 'form-control']) ?>
        </div>

        <div class="form-group">
            <?php
            // With model & without ActiveForm
            // Check init for img
            (!empty($social->fb_img)) ? $initialPreview = $social->fb_img : $initialPreview = '';
            echo '<label class="control-label">Upload Image Facebook</label>';
            echo FileInput::widget([
                'id' => 'fb-image',
                'name' => 'fb-image',
                'language' => 'en',
                'options' => [
                    'accept' => 'image/*',
                    'multiple' => false
                ],
                'pluginOptions' => [
                    'uploadUrl' => Url::to(['/admin/whoarewe/items/uploads']),
                    'showPreview' => true,
                    'initialPreview'=>[
                        $initialPreview,
                    ],
                    'allowedFileExtensions'=>['jpg','gif','png'],
                    'previewFileType' => 'any',
                    'initialPreviewAsData'=>true,
                    'showCaption' => false,
                    'showRemove' => false,
                    'browseClass' => 'btn btn-primary btn-block',
                    'browseIcon' => '<i class="glyphicon glyphicon-camera"></i> ',
                    'browseLabel' =>  'Upload Photo'
                ],
            ]);
            ?>
        </div>
    </div>
<?
$js = <<< JS
    var fbimage = "$initialPreview";
    $(function(){
        $("#count-description").text($("#seotext-description").val().length);
        $("#seotext-description").keyup(function(){
        $("#count-description").text($(this).val().length);
        });
        
        $("#count-title").text($("#seotext-title").val().length);
        $("#seotext-title").keyup(function(){
        $("#count-title").text($(this).val().length);
        });
    });
    $('#fb-image').on('fileuploaded', function(event, data, previewId, index) {
        var form = data.form, files = data.files, extra = data.extra,
            response = data.response, reader = data.reader;
        fbimage = response.file_name;
    });
    $('button[type=submit]').click(function(){
        var social = [];
        social = { 
            title : $('textarea[name=fb-title]').val(), 
            description : $('textarea[name=fb-description]').val(),
            fb_img : fbimage
        };
         social = JSON.stringify(social);
         $('#seotext-social').val(social);
         $('form').submit();
    });
    $('.fileinput-remove').click(function(){
        fbimage = '';
    });
    
        
JS;
$this->registerJs($js); ?>