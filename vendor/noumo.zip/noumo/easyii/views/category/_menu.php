<?php
use yii\helpers\Url;
$this->registerJsFile(DIR . 'assets/js/chosen/chosen.jquery.js', ['depends' => 'yii\easyii\assets\AdminAsset', 'position' => $this::POS_HEAD]); 

$this->registerCssFile(DIR . 'assets/js/chosen/chosen.min.css', ['depends' => 'yii\easyii\assets\AdminAsset', 'position' => $this::POS_HEAD]); 

$action = $this->context->action->id;

?>
<ul class="nav nav-pills">
    <li <?= ($action === 'index') ? 'class="active"' : '' ?>>
        <a href="<?= $this->context->getReturnUrl(['/admin/'.$this->context->moduleName.'/']) ?>">
            <?php if($action != 'index') : ?>
                <i class="glyphicon glyphicon-chevron-left font-12"></i>
            <?php endif; ?>
            <?= Yii::t('easyii', 'Categories') ?>
        </a>
    </li>
    <li <?= ($action === 'create') ? 'class="active"' : '' ?>><a href="<?= Url::to(['/admin/'.$this->context->moduleName.'/a/create']) ?>"><?= Yii::t('easyii', 'Create category') ?></a></li>
           
    <? 
    if($action === 'index') {
        $catsMenu = \yii\helpers\ArrayHelper::map($cats, function ($element) {
            return $element->category_id;
        }, function ($element) {
            return $element->title;
        }); 
        echo ' <select class="form-control" id="type-quick-search" style="float: right; margin-top: 5px; height: 29px; font-size: 11px; width: 80px;">
        <option value="items">Items</option>
        <option value="edit">Edit</option>
        </select>';
        echo \yii\helpers\Html::dropDownList('quick_search', null, $catsMenu,[
            'class' => 'chosen',
            'data-placeholder' => 'Search...',
            'id' => 'quick_search',
            'multiple' => 'multiple',
            'data-classname' =>  $this->context->moduleName,
            'style' => 'float: right;'
            ]);
        } ?>
    </ul>
<br/>