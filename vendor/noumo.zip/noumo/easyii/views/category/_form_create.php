<?php

use yii\easyii\helpers\Image;

use yii\helpers\Html;

use yii\helpers\Url;

use yii\widgets\ActiveForm;

use yii\easyii\widgets\SeoForm;
use wadeshuler\ckeditor\widgets\CKEditor;


$class = $this->context->categoryClass;

$settings = $this->context->module->settings;

?>

<?php $form = ActiveForm::begin([

    'enableAjaxValidation' => true,

    'options' => ['enctype' => 'multipart/form-data']

]); ?>

<?= $form->field($model, 'title') ?>
<?php if(!empty($parent)) : ?>

    <div class="form-group field-category-title required">

        <label for="category-parent" class="control-label"><?= Yii::t('easyii', 'Parent category') ?></label>

        <select class="form-control" id="category-parent" name="parent">

            <option value="" class="smooth"><?= Yii::t('easyii', 'No') ?></option>

            <?php foreach($class::find()->sort()->asArray()->all() as $node) : ?>

                <option

                    value="<?= $node['category_id'] ?>"

                    <?php if($parent == $node['category_id']) echo 'SELECTED' ?>

                    style="padding-left: <?= $node['depth']*20 ?>px;"

                ><?= $node['title'] ?></option>

            <?php endforeach; ?>

        </select>

    </div>

<?php endif; ?>
<?php if(IS_ROOT) : ?>

    <?= $form->field($model, 'slug') ?>

    <?= SeoForm::widget(['model' => $model]) ?>

<?php endif; ?>



<?= Html::submitButton(Yii::t('easyii', 'Save'), ['class' => 'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>



<?

$this->registerCss('#redactor-modal-box > div {

    margin-top: 200px !important;

}');

 ?>

 <? 
 $js = <<< JS
$('#category-title').change(function(){
    var slug = removeSpecial($(this).val().toLowerCase()).replace(/ +/g,'_').replace(/[0-9]/g,'').replace(/[^a-z0-9-_]/g,'').trim();
    var oldSlug = $('#category-slug').val();
    $('#category-slug').val(oldSlug + slug);
}); 

function removeSpecial(str = ''){
       str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g,'a');
       str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ.+/g,"e");
       str = str.replace(/ì|í|ị|ỉ|ĩ/g,"i");
       str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ.+/g,"o");
       str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g,"u");
       str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g,"y");
       str = str.replace(/đ/g,"d");
       
       /* tìm và thay thế các kí tự đặc biệt trong chuỗi sang kí tự - */ 
       //str= str.replace(/-+-/g,"-"); //thay thế 2- thành 1- 
       //str= str.replace(/^\-+|\-+$/g,""); 
       
       return str;
}
JS;
$this->registerJs($js);
 ?>