<?php
$this->title = Yii::t('easyii', 'Create setting');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>