<?php
$this->title = Yii::t('easyii', 'Edit setting');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>