<?php
$this->title = Yii::t('easyii', 'Create module');
?>
<?= $this->render('_menu') ?>
<?= $this->render('_form', ['model' => $model]) ?>