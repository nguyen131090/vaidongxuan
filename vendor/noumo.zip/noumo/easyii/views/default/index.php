<?php
$this->title = Yii::t('easyii', 'Welcome');
?>
<p><?= Yii::t('easyii', 'Welcome to control panel, choose which section you want to manage in left menu.') ?></p>