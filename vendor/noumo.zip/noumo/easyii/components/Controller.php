<?php

namespace yii\easyii\components;



use Yii;

use yii\easyii\models;

use yii\helpers\Url;



/**

 * Base easyii controller component

 * @package yii\easyii\components

 */

class Controller extends \yii\web\Controller

{

    public $enableCsrfValidation = false;

    public $layout = '@easyii/views/layouts/main';

    public $rootActions = [];

    public $error = null;



    /**

     * Check authentication, and root rights for actions

     * @param \yii\base\Action $action

     * @return bool

     * @throws \yii\web\BadRequestHttpException

     * @throws \yii\web\ForbiddenHttpException

     */

    public function beforeAction($action)

    {

        if(!parent::beforeAction($action))

            return false;



        if(Yii::$app->user->isGuest){

            Yii::$app->user->setReturnUrl(Yii::$app->request->url);

            Yii::$app->getResponse()->redirect(['/admin/sign/in'])->send();

            return false;

        }

        else{

            if(!IS_ROOT && ($this->rootActions == 'all' || in_array($action->id, $this->rootActions)) && 1==2){

                throw new \yii\web\ForbiddenHttpException('You cannot access this action');

            }



            if($action->id === 'index'){

                $this->setReturnUrl();

            }



            return true;

        }

    }



    /**

     * Write in sessions alert messages

     * @param string $type error or success

     * @param string $message alert body

     */

    public function flash($type, $message)

    {

        Yii::$app->getSession()->setFlash($type=='error'?'danger':$type, $message);

    }
     // get file in modules file
    public function getFile(){
        return \yii\helpers\ArrayHelper::map(\yii\easyii\modules\file\api\File::items(['pagination' => ['pageSize' => 0]]), 'file_id', 'title');
    }


    public function back()

    {

        return $this->redirect(Yii::$app->request->referrer);

    }



    /**

     * Set return url for module in sessions

     * @param mixed $url if not set, returnUrl will be current page

     */

    public function setReturnUrl($url = null)

    {

        Yii::$app->getSession()->set($this->module->id.'_return', $url ? Url::to($url) : Url::current());

    }

    //convert string to URL 
     public function convertToUrl($str){
        // $str = preg_replace('@[\s!:;_\?=\\\+\*/%&#]+@', '', $str);
        $str = strtolower($str);
      //convert string to lowercase
        $str = str_replace(' ', '-', $str);
        $str = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $str);
          $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
          $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
          $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
          $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
          $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
          $str = preg_replace("/(đ)/", 'd', $str);
          $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
          $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
          $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
          $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
          $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
          $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
          $str = preg_replace("/(Đ)/", 'D', $str);
          $str = str_replace(["'","`"], '', $str);
          return $str;
    }

    /**

     * Get return url for module from session

     * @param mixed $defaultUrl if return url not found in sessions

     * @return mixed

     */

    public function getReturnUrl($defaultUrl = null)

    {

        return Yii::$app->getSession()->get($this->module->id.'_return', $defaultUrl ? Url::to($defaultUrl) : Url::to('/admin/'.$this->module->id));

    }



    /**

     * Formats response depending on request type (ajax or not)

     * @param string $success

     * @param bool $back go back or refresh

     * @return mixed $result array if request is ajax.

     */

    public function formatResponse($success = '', $back = true)

    {

        if(Yii::$app->request->isAjax){

            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

            if($this->error){

                return ['result' => 'error', 'error' => $this->error];

            } else {

                $response = ['result' => 'success'];

                if($success) {

                    if(is_array($success)){

                        $response = array_merge(['result' => 'success'], $success);

                    } else {

                        $response = array_merge(['result' => 'success'], ['message' => $success]);

                    }

                }

                return $response;

            }

        }

        else{

            if($this->error){

                $this->flash('error', $this->error);

            } else {

                if(is_array($success) && isset($success['message'])){

                    $this->flash('success', $success['message']);

                }

                elseif(is_string($success)){

                    $this->flash('success', $success);

                }

            }

            return $back ? $this->back() : $this->refresh();

        }

    }

}