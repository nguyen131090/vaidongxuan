## EasyiiCMS ##

Control panel and tools based on php framework Yii2. Easy cms for easy websites.

This repository is development package (yii2 extension).

#### You can find full information in links bellow ####
* [Homepage](http://easyiicms.com)
* [Installation](http://easyiicms.com/docs/install)
* [Demo](http://easyiicms.com/demo)

#### Contacts ####

Feel free to email me on noumohope@gmail.com
