$(function(){
    var contentsBody = $('#content-table > tbody');
    var addButton = $('#content-add');
    var saveButton = $('#content-save');
    var uploadingText = $('#uploading-text');
    var uploadingTextInterval;

    if(location.hash){
        $('img'+location.hash).closest('tr').addClass('info');
    }

    addButton.on('click', function(){
        $('#form-add').removeClass('hidden');
    });
    $('#content-description').on('change', function(){
        var $this = $(this);

        addButton.addClass('disabled');
        uploadingText.show();
        uploadingTextInterval = setInterval(dotsAnimation, 300);

        var uploaded = 0;
        
                $.ajax({
                    url: $this.closest('form').attr('action'),
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: formData,
                    type: 'post',
                    success: function(response){
                        if(response.result === 'success'){
                            var html = $(contentTemplate
                                .replace(/\{\{content_id\}\}/g, response.photo.id)
                                .replace(/\{\{photo_description\}\}/g, '')
                                .replace(/\{\{photo_type\}\}/g, ''))
                                .hide();

                            var prevId = $('tr[data-id='+( response.content.id - 1 )+']', contentsBody);
                            if(prevId.get(0)){
                                prevId.before(html);
                            } else {
                                contentsBody.prepend(html);
                            }
                            html.fadeIn();
                            checkEmpty();
                        } else {
                            alert(response.error);
                        }

                        if(++uploaded >= $this.prop('files').length)
                        {
                            addButton.removeClass('disabled');
                            uploadingText.hide();
                            clearInterval(uploadingTextInterval);
                        }
                    }
                });
    });

    contentsBody.on('input propertychange', '.content-type', function(){
        var saveBtn = $(this).closest('tr').find('.save-content-description');
        if(saveBtn.hasClass('disabled')){
            saveBtn.removeClass('disabled').on('click', function(e){
                e.preventDefault();
                var $this = $(this).unbind('click').addClass('disabled');
                var tr = $this.closest('tr');
                var text = $this.siblings('.content-description').val();
                var type = tr.find('.content-type').val();
                $.post(
                    $this.attr('href'),
                    {description: text, type: type},
                    function(response){
                        if(response.result === 'success'){
                            notify.success(response.message);
                            tr.find('.plugin-box').attr('title', text);
                        }
                        else{
                            alert(response.error);
                        }
                    },
                    'json'
                );
                return false;
            });
        }
    });
    var saveBtn = $('.save-content-description');
    saveBtn.on('click', function(e){
            e.preventDefault();
                var $this = $(this).unbind('click');
                var tr = $this.closest('tr');
                var text = CKEDITOR.instances['ckeditor-'+$(this).data('id')].getData();
                var type = tr.find('.content-type').val();
                $.post(
                    $this.attr('href'),
                    {description: text, type: type},
                    function(response){
                        if(response.result === 'success'){
                            notify.success(response.message);
                            tr.find('.plugin-box').attr('title', text);
                        }
                        else{
                            alert(response.error);
                        }
                    },
                    'json'
                );
                return false;
    });

    

    contentsBody.on('click', '.delete-content', function(){
        var $this = $(this).addClass('disabled');
        if(confirm($this.attr('title')+'?')){
            $.getJSON($this.attr('href'), function(response){
                $this.removeClass('disabled');
                if(response.result === 'success'){
                    notify.success(response.message);
                    $this.closest('tr').fadeOut(function(){
                        $(this).remove();
                        checkEmpty();
                    });
                } else {
                    alert(response.error);
                }
            });
        }
        return false;
    });

    function checkEmpty(){
        var table = contentsBody.parent();
        if(contentsBody.find('tr').length) {
            if(!table.is(':visible')) {
                table.show();
                $('.empty').hide();
            }
        }
        else{
            table.hide();
            $('.empty').show();
        }
    }

    var dots = 0;
    function dotsAnimation() {
        dots = ++dots % 4;
        $("span", uploadingText).html(Array(dots+1).join("."));
    }
});