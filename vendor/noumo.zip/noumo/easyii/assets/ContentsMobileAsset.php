<?php
namespace yii\easyii\assets;

class ContentsMobileAsset extends \yii\web\AssetBundle
{
    public $sourcePath = '@easyii/assets/contents-mobile';
    public $css = [
        'photos.css',
    ];
    public $js = [
        'contents-mobile.js',
        '/assets/plugins/ckeditor/ckeditor.js'
    ];
    public $depends = [
        'yii\web\JqueryAsset',
    ];
}
