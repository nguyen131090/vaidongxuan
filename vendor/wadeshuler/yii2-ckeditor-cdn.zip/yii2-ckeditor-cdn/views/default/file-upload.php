<div class="ckeditor-default-index">
    <?= $message ?>
</div>
